import axios from 'axios';

const API_URL = VITE_URL_BASE; // URL base de la API

export const fetchProducts = async () => {
    try {
        const response = await axios.get(`${API_URL}/products`); // Cambia `/products` al endpoint correcto si es diferente
        return response.data; // Retorna los datos de la API
    } catch (error) {
        throw new Error('Error fetching products');
    }
};
