import axios from 'axios';

const API_URL = VITE_URL_BASE;
s
export const register = async (email, password) => {
    try {
      const response = await axios.post(API_URL, {
        name: firstname,
        lastname: lastname,
        email: email,
        password: password,
      });
  
      return response.data; // Retorna la data que la API proporciona
    } catch (error) {
      if (error.response) {
        // Diferente a 200
        throw new Error(error.response.data.message || 'Error al crear usuario');
      } else if (error.request) {
        // No se recibió respuesta del servidor
        throw new Error('No responde el servidor');
      } else {
        // Error al configurar la solicitud
        throw new Error('Ocurrió un error en la solicitud');
      }
    }
  };