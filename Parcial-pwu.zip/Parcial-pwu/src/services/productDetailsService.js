import axios from 'axios';

const API_URL = VITE_URL_BASE

//producto por ID
export const fetchProductById = async (id) => {
  try {
    // ID a URL para obtener el producto específico
    const response = await axios.get(`${API_URL}/products/${id}`);
    
    // Datos del producto
    return response.data;
  } catch (error) {
    console.error('Error al obtener el producto:', error);
    throw error;
  }
};