import React, { useState } from 'react';
import ProductDetails from '../components/ProductDetails';

export const Product = () => {

    return (
        <>      
        <ProductDetails />
        </>
    )
}