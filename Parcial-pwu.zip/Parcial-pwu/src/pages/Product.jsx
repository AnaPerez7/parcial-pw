import React, { useState } from 'react';
import Login from './components/Login';
import ProductList from './components/ProductList';

export const Product = () => {

    return (
        <>      
        <ProductList />
        </>
    )
}