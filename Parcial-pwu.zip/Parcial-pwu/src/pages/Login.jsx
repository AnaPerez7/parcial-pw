import React from "react";
import "../styles/Login.css";
import logo from "../assets/shoes.svg";
import {ButtonsLogin} from '../components/ButtonsLogin'
export const Login = () => {
  return (
    <div className="container_principal">
        <div className="container_bg_image"></div>
        <div className="container_down">
            <div className="container_down_part_up"></div>
        </div>
        <div className="container_form">
            <div className="container_form_part_up"></div>
            <br />
            <div className="container_form_name">
                <h1>CLOBBLER</h1>
                <span className="container_form_store">Tienda de Zapatos</span><br /><br />
            </div>
            <form>
                <label htmlFor="username">Usuario</label>
                <input type="text" id="username" placeholder="Ingresa tu usuario" />

                <label htmlFor="password">Contraseña</label>
                <input type="password" id="password" placeholder="Ingresa tu contraseña" />

                <ButtonsLogin/>
                <div className="footer">
                    <p>¿No tienes una cuenta? <a href="#">Regístrate</a></p>
                </div>
            </form>
        </div>
    </div>
  );
};
