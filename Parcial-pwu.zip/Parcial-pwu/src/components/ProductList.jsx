import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { fetchProducts } from '../services/productService'; //API
import '../styles/Product.css';

const ProductList = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    // Llamar API cuando el componente se sube
    const getProducts = async () => {
      try {
        const data = await fetchProducts();
        setProducts(data); // Guarda los productos en el estado
      } catch (error) {
        setError('Error al recorrer los productos');
      } finally {
        setLoading(false);
      }
    };

    getProducts();
  }, []);

  const handleProductClick = (id) => {
    navigate(`/products/${id}`);
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>{error}</div>;
  }

  return (
    <div className="product-list">
      <h2>Products</h2>
      <div className="products">
        {products.map((product) => (
          <div
            key={product._id}
            className="product-item"
            onClick={() => handleProductClick(product._id)}
          >
            <img src={product.image} alt={product.name} />
            <h3>{product.name}</h3>
            <p>{product.price}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ProductList;
