import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { login } from '../services/authService'; 
import Swal from 'sweetalert2';
import '../styles/Login.css';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await login(email, password);

      // Si el login es exitoso
      Swal.fire({
        icon: 'success',
        title: 'Ingreso exitoso',
        text: `Bienvenido, ${response.user.name}!`, 
      });

      // Redirige a la página de productos
      navigate('/products');
      
      // Guardar el token en localStorage
      localStorage.setItem('token', response.token);

    } catch (error) {
      Swal.fire({
        icon: 'error',
        title: 'Inicio de sesión fallida',
        text: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-container">
      <form className="login-form" onSubmit={handleLogin}>
        <h2>Login</h2>
        <div className="form-group">
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <input
            type="password"
            placeholder="Contraseña"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <button type="submit" disabled={loading}>
          {loading ? 'Ingresando...' : 'Login'}
        </button>
        <p>
          Don't have an account? <a href="/register">Create an account</a>
        </p>
      </form>
    </div>
  );
};