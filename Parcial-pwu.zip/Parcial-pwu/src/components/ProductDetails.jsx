import React, { useEffect, useState } from 'react';
import { fetchProductById } from './services/productDetailsService';

const ProductDetail = ({ productId }) => {
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const getProduct = async () => {
      try {
        // GET con el ID
        const productData = await fetchProductById(productId);
        setProduct(productData);
      } catch (err) {
        setError('Error al cargar el producto.');
      } finally {
        setLoading(false);
      }
    };

    getProduct();
  }, [productId]);

  if (loading) return <div>Cargando...</div>;
  if (error) return <div>{error}</div>;

  return (
    <div>
      <h2>Detalles del Producto</h2>
      {product ? (
        <div>
          <h3>{product.name}</h3>
          <p>Precio: {product.price}</p>
          <p>Precio: {product.marca}</p>
          <p>Descripción: {product.description}</p>
        </div>
      ) : (
        <p>No se encontró el producto.</p>
      )}
    </div>
  );
};

export default ProductDetail;