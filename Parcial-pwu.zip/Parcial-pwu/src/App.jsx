import { Route, Router, Routes } from 'react-router-dom'
import './App.css'
//import { Login } from './components/Login'
import { Login } from './pages/Login'
import { Register } from './pages/Register'
import { ProductList} from './components/ProductList'
import { ProductDetails } from './components/ProductDetails'

function App() {
  return (
    <Router>
      <Routes>
        <Route exact path="/" element={<Login />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/products" element={<ProductList />} />
        <Route path="/products/:_id" element={<ProductDetails />} />
      </Routes>
    </Router>  
  );
    
}

export default App
